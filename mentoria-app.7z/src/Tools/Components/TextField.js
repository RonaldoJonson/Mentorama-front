import React from 'react'
import {TextField} from "@material-ui/core";

export function TextField_Basic (props) {
    return <div>
        <TextField id={props.InputTitle + "-input"} label={props.InputTitle} variant={props.InputVariant} fullWidth value={props.value} onChange={props.onChange} />
    </div>
}

export function TextField_fullwidth (props) {
    return <div>
        <TextField id={props.InputTitle + "-input"} fullWidth label={props.InputTitle} variant={props.InputVariant} value={props.value} fullWidth onChange={props.onChange} />
    </div>
}

export function TextField_password (props) {
    return <div>
        <TextField id={props.InputTitle + "-input"} label={props.InputTitle} variant={props.InputVariant} type="password" autoComplete="current-password" fullWidth value={props.value} onChange={props.onChange}/>
    </div>
}
