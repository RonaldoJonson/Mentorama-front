import React from 'react';
import styled from 'styled-components';

export function Footer (){
    return <FooterDiv>
        <section>
            <h2>teste</h2>
        </section>
    </FooterDiv>
}

const FooterDiv = styled.footer`
        padding: 10rem 0;
        font-size: 1.4rem;
        color: #f7f7f7;
        background-color:${props => props.theme.colors.primary}
    `