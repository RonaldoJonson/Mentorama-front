import React from 'react';
import styled from 'styled-components';
import {O_Form_login} from '../Modules/login-form';
import {A_Typography_Title} from '../Components/Paragraph';

function T_LoginPage (props){
    return <LoginContainer>
        <MainBar>
            <LoginSideBar>
                <A_Typography_Title title='Login' text='login to your account' size="large"/>
                <O_Form_login></O_Form_login>   
            </LoginSideBar>
        </MainBar>
        <ImageContainer>
            <img src={props.image}/>
        </ImageContainer>
    </LoginContainer>
}

export default T_LoginPage;

const LoginContainer = styled.div`
    display: flex;
`

const MainBar = styled.div`
    width:50vw;
    height:100vh;

    display: flex;
    flex-direction: column;
    justify-content: center;
`

const LoginSideBar = styled.div`
    margin: auto;
    width:50%;
    height:50%;

    display: flex;
    flex-direction: column;
    justify-content: space-between;
`

const ImageContainer = styled.div`
    width:50%;
    height:100vh;
    background-color:${props => props.theme.colors.primary}; 
`