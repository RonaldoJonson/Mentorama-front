import React , {useState} from 'react';
import styled from 'styled-components';
import {TextField_Basic, TextField_password } from "../Components/TextField";
import {A_Button_basic} from '../Components/Button';

import { useHistory } from "react-router-dom";

export function O_Form_login () {
    const [userEmail, setUserEmail] = useState('');
    const [password, setPassword] = useState('');

    const history = useHistory();

    const NextPage = () => {
        console.log("OK")
        history.push("/home");
    };

    return <ContentFlex>
        <TextField_Basic InputTitle="Email" InputVariant="standard" value={userEmail} onChange={(event) => setUserEmail(event.target.value)}/>
        <TextField_password InputTitle="Password" InputVariant="standard" value={password} onChange={(event) => setPassword(event.target.value)}/>       
        <A_Button_basic InputTitle="Login" InputVariant="contained" buttonColor="primary" buttonText="Login" handleClick={NextPage}/>  
    </ContentFlex>
}

const ContentFlex = styled.div`
        width: 100%;
        height: 100%;
        margin: auto;
        display: flex;
        flex-direction: column;
        justify-content: space-around;
    `