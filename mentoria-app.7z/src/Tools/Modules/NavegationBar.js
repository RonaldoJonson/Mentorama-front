import React  from 'react';
import styled from 'styled-components';
import {A_MenuIcon, A_NotificationsIcon} from '../Components/Icon'
import {A_SearchBar_basic} from '../Components/SearchBar'

export function NavegationBar () {
    return <Navegationbar>
        <NavBarFlex>
            <A_MenuIcon></A_MenuIcon>
            <div>
                <A_SearchBar_basic></A_SearchBar_basic>
            </div>
            <A_NotificationsIcon></A_NotificationsIcon>
        </NavBarFlex>
    </Navegationbar>
}

const Navegationbar = styled.div`
        width: 100%;
        height: 50px;
        display: flex;
        align-items:center;
        background-color:${props => props.theme.colors.primary}
    `
const NavBarFlex = styled.section`
        display: flex;
        justify-content: space-between;
        align-items:center;

`
