export default {
    title: 'dark',

    colors: {
        primary: '#202020',
        secondary: '#181818',

        icons: '#FFFFFF',

        title: '#FFFFFF',
        subTitle: '#AAAAA5',
        white: '#FFFFFF',
    }
}

//${props => props.theme.colors.primary}