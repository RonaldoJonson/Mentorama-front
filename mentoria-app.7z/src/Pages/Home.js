import React from 'react';
import styled from 'styled-components';
import {NavegationBar} from '../Tools/Modules/NavegationBar';
import { Footer } from '../Tools/Prefabs/Footer';

import hero from '../Assets/Imgs/hero.jpg';

function Home (){
    return <div>
        <NavegationBar></NavegationBar>
            <HomeDiv>
               <HeroImg src={hero}/>
            </HomeDiv> 
        <Footer></Footer>
    </div>
}

export default Home;

const HomeDiv = styled.div`
    height: 95vh;
    background-image: linear-gradient(to right bottom, #7ed56fd3, #28b485d3) , url(../img/hero.jpg);
    background-size: cover;
    background-position: top;
    position: relative;
`

const HeroImg = styled.img`
    width:100%;
    height:100%;
    object-fit:cover;
`