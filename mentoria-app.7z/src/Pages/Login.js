import React from 'react';
import T_LoginPage from '../Tools/Templates/Template-Login';

function LoginPage (){
    return <div>
        <T_LoginPage image="https://picsum.photos/1000/1000"></T_LoginPage>
    </div>
}

export default LoginPage;